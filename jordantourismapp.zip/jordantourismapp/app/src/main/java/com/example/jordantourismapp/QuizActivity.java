package com.example.jordantourismapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    RadioGroup q1Group, q2Group, q3Group, q4Group, q5Group;
    Button submitQuizButton, backButton;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        q1Group = findViewById(R.id.q1Group);
        q2Group = findViewById(R.id.q2Group);
        q3Group = findViewById(R.id.q3Group);
        q4Group = findViewById(R.id.q4Group);
        q5Group = findViewById(R.id.q5Group);

        submitQuizButton = findViewById(R.id.submitQuizButton);
        backButton = findViewById(R.id.backButton);
        resultText = findViewById(R.id.resultText);

        submitQuizButton.setOnClickListener(v -> {
            int score = 0;

            if (q1Group.getCheckedRadioButtonId() == R.id.q1a1) score++;
            if (q2Group.getCheckedRadioButtonId() == R.id.q2a2) score++;
            if (q3Group.getCheckedRadioButtonId() == R.id.q3a1) score++;
            if (q4Group.getCheckedRadioButtonId() == R.id.q4a1) score++;
            if (q5Group.getCheckedRadioButtonId() == R.id.q5a1) score++;

            resultText.setText("نتيجتك هي " + score + " من 5");
        });

        backButton.setOnClickListener(v -> finish());
    }
}