package com.example.jordantourismapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button startBtn;
    Button videoBtn;
    Button quizBtn;
    Button ratingBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startButton);
        videoBtn = findViewById(R.id.videoButton);
        quizBtn = findViewById(R.id.quizButton);
        ratingBtn = findViewById(R.id.ratingButton);

        startBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlacesActivity.class);
            startActivity(intent);
        });

        videoBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, VideoActivity.class);
            startActivity(intent);
        });

        quizBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, QuizActivity.class);
            startActivity(intent);
        });

        ratingBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RatingActivity.class);
            startActivity(intent);
        });
    }
}