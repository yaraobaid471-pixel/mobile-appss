package com.example.jordantourismapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class JordanPlacesActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jordanplacesactivity);
    }
}