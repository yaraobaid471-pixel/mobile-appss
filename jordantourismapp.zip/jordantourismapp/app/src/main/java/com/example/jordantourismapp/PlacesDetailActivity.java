package com.example.jordantourismapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlacesDetailActivity extends AppCompatActivity {

    TextView placeTitle;
    TextView placeDescription;
    ImageView placeImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_detail);

        placeTitle = findViewById(R.id.placeTitle);
        placeDescription = findViewById(R.id.placeDescription);
        placeImage = findViewById(R.id.placeImage);

        String placeName = getIntent().getStringExtra("placeName");

        if (placeName != null) {

            if (placeName.equals("البتراء")) {
                placeTitle.setText("البتراء");
                placeDescription.setText("البتراء مدينة اثرية تاريخية في الاردن وهي من عجائب الدنيا السبع الجديدة وتتميز بالواجهات المنحوتة في الصخور الوردية");
                placeImage.setImageResource(R.drawable.petra);

            } else if (placeName.equals("جرش")) {
                placeTitle.setText("جرش");
                placeDescription.setText("جرش من اجمل المدن الاثرية في الاردن وتشتهر بالاعمدة الرومانية والمسارح القديمة");
                placeImage.setImageResource(R.drawable.jerash);

            } else if (placeName.equals("العقبة")) {
                placeTitle.setText("العقبة");
                placeDescription.setText("العقبة مدينة ساحلية جميلة تقع جنوب الاردن وتشتهر بالشواطئ والرياضات البحرية");
                placeImage.setImageResource(R.drawable.aqaba);

            } else if (placeName.equals("البحر الميت")) {
                placeTitle.setText("البحر الميت");
                placeDescription.setText("البحر الميت اخفض نقطة على سطح الارض ويشتهر بمياهه المالحة وطينه الغني بالمعادن");
                placeImage.setImageResource(R.drawable.deadsea);

            } else if (placeName.equals("عجلون")) {
                placeTitle.setText("عجلون");
                placeDescription.setText("عجلون منطقة جميلة مليئة بالغابات والجبال وتشتهر بقلعة عجلون والطبيعة الخضراء");
                placeImage.setImageResource(R.drawable.ajloun);
            }
        }
    }
}