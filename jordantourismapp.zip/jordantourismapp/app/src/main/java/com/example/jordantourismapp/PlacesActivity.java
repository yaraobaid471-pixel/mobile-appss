package com.example.jordantourismapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class PlacesActivity extends AppCompatActivity {

    LinearLayout petraCard;
    LinearLayout jerashCard;
    LinearLayout aqabaCard;
    LinearLayout deadSeaCard;
    LinearLayout ajlounCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);

        petraCard = findViewById(R.id.petraCard);
        jerashCard = findViewById(R.id.jerashCard);
        aqabaCard = findViewById(R.id.aqabaCard);
        deadSeaCard = findViewById(R.id.deadSeaCard);
        ajlounCard = findViewById(R.id.ajlounCard);

        petraCard.setOnClickListener(v -> openPlaceDetails("البتراء"));
        jerashCard.setOnClickListener(v -> openPlaceDetails("جرش"));
        aqabaCard.setOnClickListener(v -> openPlaceDetails("العقبة"));
        deadSeaCard.setOnClickListener(v -> openPlaceDetails("البحر الميت"));
        ajlounCard.setOnClickListener(v -> openPlaceDetails("عجلون"));
    }

    private void openPlaceDetails(String placeName) {
        Intent intent = new Intent(PlacesActivity.this, PlacesDetailActivity.class);
        intent.putExtra("placeName", placeName);
        startActivity(intent);
    }
}