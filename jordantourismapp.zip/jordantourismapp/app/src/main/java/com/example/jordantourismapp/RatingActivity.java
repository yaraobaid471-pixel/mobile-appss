package com.example.jordantourismapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RatingActivity extends AppCompatActivity {

    RatingBar ratingBar;
    Button submitRatingButton, backButton;
    TextView ratingResultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        ratingBar = findViewById(R.id.ratingBar);
        submitRatingButton = findViewById(R.id.submitRatingButton);
        backButton = findViewById(R.id.backButton);
        ratingResultText = findViewById(R.id.ratingResultText);

        submitRatingButton.setOnClickListener(v -> {
            float rating = ratingBar.getRating();
            ratingResultText.setText("شكرا لتقييمك " + rating + " نجوم");
        });

        backButton.setOnClickListener(v -> finish());
    }
}